function p_v = MtV_ind(p,N)
    p_v=p(1)+(p(2)-1)*N;
end

